"""
Ejercicio nivel 2: Cálculo de velocidades en vías colombianas
Modulo de cálculos.

Temas:
* Variables.
* Tipos de datos.
* Expresiones aritméticas.
* Instrucciones básicas y consola.
* Dividir y conquistar: funciones y paso de párametros.
* Especificacion y documentacion.
* Instrucciones condicionales.
* Diccionarios.
@author: Juan Jose Rivera

"""

def crear_sector( nombre: str, carriles: int, pendiente: float, 
                   ancho_calzada: float, ancho_berma: float, separador: bool,
                   peatones: bool, control_accesos: str, 
                   zona_recreacional: bool,cuello_de_botella: bool, 
                   zona_escolar: bool ) -> dict:
    """
    Crea un diccionario que representa un sector de la vía con todos sus 
    atributos inicializados.
    
    Parámetros
    ----------
    nombre : str
        Nombre del sector vial.
    carriles : int
        Número de carriles dentro del sector.
    pendiente : float
        Porcentaje de inclinación del sector.
    ancho_calzada : float
        Ancho en metros de la calzada del sector.
    ancho_berma : float
        Ancho en metros de la berma del sector.
    separador : bool
        Existencia de un separador en el sector.
    peatones : bool
        Existencia de concentración de peatones en el sector.
    control_accesos : str
        Tipo de control de accesos que hay en una vía.
        Puede ser “Total”, “Parcial” o “Nulo”
    zona_recreacional : bool
        Existencia de una zona recreacional en el sector.
    cuello_de_botella : bool
        Existencia de un cuello de botella en el sector.
    zona_escolar : bool
        Existencia de una zona escolar en el sector.

    Retorno
    -------
    dict
        Diccionario del sector vial con sus características.

    """

    #TODO: completar y remplazar la siguiente linea por el resultado correcto

    sector = {"nombre_sector": nombre,
                "carriles": carriles,
                "pendiente": pendiente,
                "ancho_calzada" : ancho_calzada,
                "ancho_berma" : ancho_berma,
                "separador": separador,
                "concentracion_peatones": peatones,
                "control_accesos": control_accesos,
                "zona_recreacional" : zona_recreacional,
                "cuello_de_botella": cuello_de_botella,
                "zona_escolar" : zona_escolar}

    return sector

def buscar_sector( nombre: str, s1: dict, s2: dict, s3: dict, 
                  s4: dict ) -> dict:
    """
    Busca el sector vial que coincide con el nombre pasado por parámetro.
    Si no se encuentra el sector, se retorna None.
    
    Parámetros
    ----------
    nombre : str
        Nombre del sector vial.
    s1 : dict
        Diccionario con la información del primer sector vial.
    s2 : dict
        Diccionario con la información del segundo sector vial.
    s3 : dict
        Diccionario con la información del tercer sector vial.
    s4 : dict
        Diccionario con la información del cuarto sector vial.

    Retorno
    -------
    dict
        Diccionario del sector vial con el nombre dado por parámetro.
        Retorna None si no lo encuentra.

    """
    # TODO: completar y remplazar la siguiente linea por el resultado correcto
    sector = {}
    if s1["nombre_sector"] == nombre:
        sector = s1
    elif s2["nombre_sector"] == nombre:
        sector = s2
    elif s3["nombre_sector"] == nombre:
        sector = s3
    else:
        sector = s4


    return sector


def clasificar_sector( sector: dict ) -> str:
    """
    Clasifica un sector según sus características geométricas.

    Parámetros
    ----------
    sector : dict
        Diccionario del sector vial a clasificar.

    Retorno
    -------
    str
        Retorna alguna de las 7 clasificaciones viales según características
        geométricas (A1,B1,C1,A2,B2,C2 o D2).

    """
    # TODO: completar y remplazar la siguiente linea por el resultado correcto
    clasificacion = "A1"

    if sector["ancho_calzada"] == 7.30 and sector["ancho_berma"] == 2.5:
        clasificacion = "A1"
    elif sector["ancho_calzada"] == 7.30 and sector["ancho_berma"] == 1.5:
        clasificacion = "B1"
    elif sector["ancho_calzada"] == 7.30 and sector["ancho_berma"] == 1.8:
        clasificacion = "A2"
    elif sector["ancho_calzada"] == 7.30 and sector["ancho_berma"] == 1:
        clasificacion = "B2"
    elif sector["ancho_calzada"] == 7 and sector["ancho_berma"] == 1.3:
        clasificacion = "C1"
    elif sector["ancho_calzada"] == 7 and sector["ancho_berma"] == 0.5:
        clasificacion = "C2"
    else:
        clasificacion = "D2"

    return clasificacion


def determinar_velocidad_generica( sector: dict ) -> int:
    """
    Determina la velocidad genérica del sector según sus características.

    Parámetros
    ----------
    sector : dict
        Diccionario del sector vial a analizar.

    Retorno
    -------
    int
        Velocidad genérica del sector vial en km/h.

    """
    # TODO: completar y remplazar la siguiente linea por el resultado correcto

    clasificacion = clasificar_sector(sector)

    if clasificacion == "A1" and sector["separador"] == True:
        velocidad_generica = 120
    elif clasificacion == "B1" and sector["control_accesos"] == "Parcial" and sector["separador"] == True:
        velocidad_generica = 100
    elif clasificacion == "B1" and sector["control_accesos"] == "Parcial" and sector["separador"] == False:
        velocidad_generica = 90
    elif clasificacion == "B1" and sector["control_accesos"] == "Nulo" and sector["separador"] == True:
        velocidad_generica = 90
    elif clasificacion == "B1" and sector["control_accesos"] == "Nulo" and sector["separador"] == False:
        velocidad_generica = 80
    elif clasificacion == "C1" and sector["concentracion_peatones"] == True and sector["separador"] == True:
        velocidad_generica = 70
    elif clasificacion == "C1" and sector["concentracion_peatones"] == True and sector["separador"] == False:
        velocidad_generica = 60
    elif clasificacion == "C1" and sector["concentracion_peatones"] == False and sector["separador"] == True:
        velocidad_generica = 80
    elif clasificacion == "C1" and sector["concentracion_peatones"] == False and sector["separador"] == False:
        velocidad_generica = 70
    elif clasificacion == "A2" and sector["concentracion_peatones"] == True:
        velocidad_generica = 70
    elif clasificacion == "A2" and sector["concentracion_peatones"] == False:
        velocidad_generica = 80
    elif clasificacion == "B2" and sector["concentracion_peatones"] == True:
        velocidad_generica = 60
    elif clasificacion == "B2" and sector["concentracion_peatones"] == False:
        velocidad_generica = 70
    elif clasificacion == "C2":
        velocidad_generica = 50
    else:
        velocidad_generica = 40

    return velocidad_generica

def calcular_velocidad_promedio( sector: dict ) -> float:
    """
    Calcula la velocidad promedio de un sector según sus restricciones por
    sitios especiales.

    Parámetros
    ----------
    sector : dict
        Diccionario del sector vial a analizar.

    Retorno
    -------
    float
        Velocidad promedio del sector en km/h redondeada a 2 cifras decimales.

    """
    # TODO: completar y remplazar la siguiente linea por el resultado correcto

    numerador = determinar_velocidad_generica(sector)
    denominador = 1
    if sector["zona_recreacional"] == True:
        numerador += 30
        denominador += 1
    if sector["cuello_de_botella"] == True:
        numerador += 40
        denominador += 1
    if sector["zona_escolar"] == True:
        numerador += 30
        denominador += 1

    velocidad_prom = numerador / denominador
    return round(velocidad_prom,2)

def contar_libres_de_restriccion( s1: dict, s2: dict, s3: dict,
                                 s4: dict ) -> int:
    """
    Cuenta los sectores que no tienen sitios especiales.

    Parámetros
    ----------
    s1 : dict
        Diccionario con la información del primer sector vial.
    s2 : dict
        Diccionario con la información del segundo sector vial.
    s3 : dict
        Diccionario con la información del tercer sector vial.
    s4 : dict
        Diccionario con la información del cuarto sector vial.

    Retorno
    -------
    int
        Número de sectores que no tienen sitios especiales.

    """
    # TODO: completar y remplazar la siguiente linea por el resultado correcto
    libres = 0
    if s1["zona_recreacional"] == False and s1["cuello_de_botella"] == False and s1["zona_escolar"] == False:
        libres += 1
    if s2["zona_recreacional"] == False and s2["cuello_de_botella"] == False and s2["zona_escolar"] == False:
        libres += 1
    if s3["zona_recreacional"] == False and s3["cuello_de_botella"] == False and s3["zona_escolar"] == False:
        libres += 1
    if s4["zona_recreacional"] == False and s4["cuello_de_botella"] == False and s4["zona_escolar"] == False:
        libres += 1

    return libres

def determinar_pendiente_menor( pendiente: float, s1: dict, s2: dict, s3: dict,
                               s4: dict ) -> str:
    """
    Determina cuáles sectores tienen una pendiente menor a un número dado.

    Parámetros
    ----------
    pendiente : float
        Conta superior de la pendiente de los sectores a encontrar.
    s1 : dict
        Diccionario con la información del primer sector vial.
    s2 : dict
        Diccionario con la información del segundo sector vial.
    s3 : dict
        Diccionario con la información del tercer sector vial.
    s4 : dict
        Diccionario con la información del cuarto sector vial.
        
    Retorno
    -------
    str
        Una cadena con todos los nombres de los sectores que tienen una 
        pendiente inferior a la dada por parámetro.
    
    """
    # TODO: completar y remplazar la siguiente linea por el resultado correcto
    n1 = ""
    n2 = ""
    n3 = ""
    n4 = ""

    if s1["pendiente"] < pendiente:
        n1 = s1["nombre_sector"]
    if s2["pendiente"] < pendiente:
        n2 = s2["nombre_sector"]
    if s3["pendiente"] < pendiente:
        n3 = s3["nombre_sector"]
    if s4["pendiente"] < pendiente:
        n4 = s4["nombre_sector"]

    retorno = ""

    if len(n1)>1:
        retorno += n1 + ', '
    if len(n2)>1:
        retorno += n2 + ', '
    if len(n3)>1:
        retorno += n3 + ', '
    if len(n4)>1:
        retorno += n4

    return retorno


def velocidad_maxima( s1: dict, s2: dict, s3: dict, s4: dict ) -> dict:
    """
    Retorna el diccionario del sector con la velocidad genérica más alta. En
    caso de encontrar dos sectores con la misma velocidad, se debe mostrar el
    nombre del sector que vaya primero alfabéticamente.

    Parámetros
    ----------
    s1 : dict
        Diccionario con la información del primer sector vial.
    s2 : dict
        Diccionario con la información del segundo sector vial.
    s3 : dict
        Diccionario con la información del tercer sector vial.
    s4 : dict
        Diccionario con la información del cuarto sector vial.

    Retorno
    -------
    dict
        El diccionario con la velocidad genérica más alta.

    """
    # TODO: completar y remplazar la siguiente linea por el resultado correcto

    velocidad_sector1 = determinar_velocidad_generica(s1)
    velocidad_sector2 = determinar_velocidad_generica(s2)
    velocidad_sector3 = determinar_velocidad_generica(s3)
    velocidad_sector4 = determinar_velocidad_generica(s4)

    maxima = velocidad_sector1
    retorno = s1

    if velocidad_sector2 > maxima:
        maxima = velocidad_sector2
        retorno = s2
    if velocidad_sector3 > maxima:
        maxima = velocidad_sector3
        retorno = s3
    if velocidad_sector4 > maxima:
        maxima = velocidad_sector4
        retorno = s4

    return retorno

def contar_sitios_especiales( s1: dict, s2: dict, s3: dict, s4: dict ) -> dict:
    """
    Retorna un diccionario con la cantidad de sitios especiales que hay en
    todos los sectores.

    Parámetros
    ----------
    s1 : dict
        Diccionario con la información del primer sector vial.
    s2 : dict
        Diccionario con la información del segundo sector vial.
    s3 : dict
        Diccionario con la información del tercer sector vial.
    s4 : dict
        Diccionario con la información del cuarto sector vial.

    Retorno
    -------
    dict
        Diccionario que tiene como llaves el nombre del sitio especial y como
        valores la cantidad de sitios especiales que existen de ese sitio.
        Las llaves deben ser "zona_recreacional", "cuello_de_botella" y
        "zona_escolar"

    """

    zonas_escolares = 0
    zonas_recreacionales = 0
    cuellos_de_botella = 0

    if s1["zona_escolar"] == True:
        zonas_escolares += 1
    if s2["zona_escolar"] == True:
        zonas_escolares += 1
    if s3["zona_escolar"] == True:
        zonas_escolares += 1
    if s4["zona_escolar"] == True:
        zonas_escolares += 1

    if s1["cuello_de_botella"] == True:
        cuellos_de_botella +=1
    if s2["cuello_de_botella"] == True:
        cuellos_de_botella +=1
    if s3["cuello_de_botella"] == True:
        cuellos_de_botella +=1
    if s4["cuello_de_botella"] == True:
        cuellos_de_botella +=1

    if s1["zona_recreacional"] == True:
        zonas_recreacionales += 1
    if s2["zona_recreacional"] == True:
        zonas_recreacionales += 1
    if s3["zona_recreacional"] == True:
        zonas_recreacionales += 1
    if s4["zona_recreacional"] == True:
        zonas_recreacionales += 1

    retorno = {"zona_recreacional" : zonas_recreacionales, "cuello_de_botella" : cuellos_de_botella,
            "zona_escolar" : zonas_escolares}

    
    # TODO: completar y remplazar la siguiente linea por el resultado correcto
    return retorno




